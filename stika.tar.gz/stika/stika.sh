LF=$(printf '\\\012_')
LF=${LF%_}

tr "\n" " " > temp0
cat temp0 | tr "\r" " " > temp1
cat temp1 | sed -e 's/<valsi /'"$LF"'<valsi /g' > temp0
cat temp0 | sed -e '/xml version/d' > temp1
cat temp1 | sed -e 's/<nlword word=/'"$LF"'<nlword word=/g'  > temp0
echo "" >> temp0
csplit temp0 '/<nlword word=/' {0}
sed -f lai-sed0 < xx00 > vlaste00tab
sed -f lai-sed1 < xx01 > vlaste01tab
rm temp* xx*